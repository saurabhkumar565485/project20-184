import { useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { 
  Home, 
  LogIn, 
  Info, 
  Building2, 
  Menu, 
  X,
  Brain,
  Users,
  Target 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navigationItems = [
  {
    title: "Home",
    url: "/",
    icon: Home,
    description: "Dashboard & Overview"
  },
  {
    title: "Login",
    url: "/login", 
    icon: LogIn,
    description: "Student & Company Access"
  },
  {
    title: "Project Info",
    url: "/project-info",
    icon: Info,
    description: "AI/ML System Architecture"
  },
  {
    title: "Companies",
    url: "/companies",
    icon: Building2,
    description: "Internship Opportunities"
  }
];

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}

export function Sidebar({ isOpen, setIsOpen }: SidebarProps) {
  const location = useLocation();
  const currentPath = location.pathname;

  const isActive = (path: string) => currentPath === path;

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-primary/20 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "fixed left-0 top-0 h-full bg-gradient-primary shadow-custom-lg z-50 transition-transform duration-300 ease-in-out",
        "w-80 lg:w-72",
        isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        {/* Header */}
        <div className="p-6 border-b border-primary-glow/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary-glow/20 rounded-xl">
                <Brain className="h-6 w-6 text-accent" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-primary-foreground">
                  PM Internship
                </h1>
                <p className="text-sm text-primary-foreground/70">
                  AI-Powered Matching
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(false)}
              className="lg:hidden text-primary-foreground hover:bg-primary-glow/20"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.url);
            
            return (
              <NavLink
                key={item.title}
                to={item.url}
                onClick={() => setIsOpen(false)}
                className={cn(
                  "flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200",
                  "hover:bg-primary-glow/20 hover:translate-x-1",
                  active 
                    ? "bg-accent text-accent-foreground shadow-custom-md" 
                    : "text-primary-foreground hover:text-accent"
                )}
              >
                <Icon className={cn(
                  "h-5 w-5 transition-colors",
                  active ? "text-accent-foreground" : "text-primary-foreground"
                )} />
                <div className="flex-1">
                  <div className="font-medium">{item.title}</div>
                  <div className={cn(
                    "text-xs opacity-70",
                    active ? "text-accent-foreground" : "text-primary-foreground"
                  )}>
                    {item.description}
                  </div>
                </div>
              </NavLink>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-primary-glow/30">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 text-primary-foreground/70 text-sm">
              <Target className="h-4 w-4" />
              <span>Smart Career Matching</span>
            </div>
            <p className="text-xs text-primary-foreground/50 mt-1">
              Powered by AI/ML Technology
            </p>
          </div>
        </div>
      </div>
    </>
  );
}