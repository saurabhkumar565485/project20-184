import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, 
  Monitor, 
  Server, 
  Database, 
  Settings, 
  ArrowRight,
  Users,
  Target,
  BarChart3,
  Shield,
  Zap,
  CheckCircle
} from "lucide-react";

const systemComponents = [
  {
    title: "AI Engine",
    icon: Brain,
    description: "Machine Learning algorithms for intelligent matching",
    color: "bg-primary",
    features: [
      "Skills assessment & matching",
      "Preference analysis", 
      "Diversity optimization",
      "Performance prediction"
    ]
  },
  {
    title: "Frontend",
    icon: Monitor,
    description: "React-based responsive user interface",
    color: "bg-accent",
    features: [
      "Student dashboard",
      "Company portal",
      "Real-time notifications",
      "Mobile-first design"
    ]
  },
  {
    title: "Backend API", 
    icon: Server,
    description: "Scalable Node.js microservices architecture",
    color: "bg-success",
    features: [
      "RESTful API design",
      "Authentication & security",
      "Rate limiting",
      "Load balancing"
    ]
  },
  {
    title: "Database",
    icon: Database,
    description: "MongoDB for flexible data storage",
    color: "bg-primary-glow",
    features: [
      "Student profiles",
      "Company requirements",
      "Matching history",
      "Analytics data"
    ]
  }
];

const tools = [
  { name: "TensorFlow", category: "ML Framework" },
  { name: "React", category: "Frontend" },
  { name: "Node.js", category: "Backend" },
  { name: "MongoDB", category: "Database" },
  { name: "Docker", category: "DevOps" },
  { name: "AWS", category: "Cloud" }
];

const features = [
  {
    icon: Target,
    title: "Smart Matching Algorithm",
    description: "AI-powered system analyzes student skills, preferences, and company requirements for optimal matches."
  },
  {
    icon: Shield,
    title: "Secure & Compliant",
    description: "End-to-end encryption with compliance to data protection and affirmative action policies."
  },
  {
    icon: Zap,
    title: "Real-time Processing",
    description: "Instant matching and notifications with sub-second response times for urgent placements."
  },
  {
    icon: BarChart3,
    title: "Analytics Dashboard",
    description: "Comprehensive insights into placement trends, success rates, and diversity metrics."
  }
];

export default function ProjectInfo() {
  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-5xl font-bold text-primary">System Architecture</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive overview of our AI-powered internship matching platform 
            built with modern technologies and intelligent algorithms.
          </p>
        </div>

        {/* Architecture Flow */}
        <Card className="bg-gradient-card shadow-custom-lg">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2 text-2xl">
              <Brain className="h-8 w-8 text-primary" />
              AI/ML System Flow
            </CardTitle>
            <CardDescription>
              Data flow through our intelligent matching system
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {systemComponents.map((component, index) => {
                const Icon = component.icon;
                return (
                  <div key={component.title} className="relative">
                    <Card className="h-full hover:shadow-custom-md transition-all duration-300 group">
                      <CardHeader className="text-center pb-3">
                        <div className={`mx-auto w-16 h-16 ${component.color} rounded-2xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                          <Icon className="h-8 w-8 text-white" />
                        </div>
                        <CardTitle className="text-lg">{component.title}</CardTitle>
                        <CardDescription className="text-sm">
                          {component.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {component.features.map((feature, idx) => (
                            <li key={idx} className="flex items-center gap-2 text-sm">
                              <CheckCircle className="h-3 w-3 text-success flex-shrink-0" />
                              <span>{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                    
                    {/* Arrow connector */}
                    {index < systemComponents.length - 1 && (
                      <div className="hidden lg:flex absolute top-1/2 -right-3 transform -translate-y-1/2 z-10">
                        <ArrowRight className="h-6 w-6 text-primary" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Skills Chart Simulation */}
        <div className="grid lg:grid-cols-2 gap-8">
          <Card className="bg-gradient-card shadow-custom-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-6 w-6 text-primary" />
                AI/ML Skills Distribution
              </CardTitle>
              <CardDescription>
                Real-time analysis of student skill sets and market demand
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { skill: "Python Programming", students: 85, demand: 92 },
                  { skill: "Machine Learning", students: 72, demand: 88 },
                  { skill: "Data Analysis", students: 78, demand: 85 },
                  { skill: "React Development", students: 65, demand: 90 },
                  { skill: "Node.js Backend", students: 58, demand: 82 }
                ].map((item, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium">{item.skill}</span>
                      <span className="text-muted-foreground">{item.students}% match</span>
                    </div>
                    <div className="space-y-1">
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary rounded-full transition-all duration-1000"
                          style={{ width: `${item.students}%` }}
                        />
                      </div>
                      <div className="h-1 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-accent rounded-full transition-all duration-1000"
                          style={{ width: `${item.demand}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card shadow-custom-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-6 w-6 text-primary" />
                Technology Stack
              </CardTitle>
              <CardDescription>
                Modern tools powering our intelligent platform
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {tools.map((tool, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                    <span className="font-medium">{tool.name}</span>
                    <Badge variant="secondary" className="text-xs">
                      {tool.category}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Key Features */}
        <Card className="bg-gradient-card shadow-custom-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Platform Features</CardTitle>
            <CardDescription>
              Comprehensive capabilities designed for optimal internship matching
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div key={index} className="flex gap-4 p-4 rounded-xl border bg-background/50">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                        <Icon className="h-6 w-6 text-primary-foreground" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-semibold text-primary mb-2">{feature.title}</h3>
                      <p className="text-muted-foreground text-sm">{feature.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Expected Outcomes */}
        <Card className="bg-gradient-primary text-primary-foreground shadow-custom-glow">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Expected Outcomes</CardTitle>
            <CardDescription className="text-primary-foreground/80">
              Transforming internship placement through intelligent automation
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div className="space-y-2">
                <Users className="h-12 w-12 mx-auto text-accent" />
                <h3 className="text-xl font-bold">50% Faster</h3>
                <p className="text-primary-foreground/80 text-sm">
                  Matching process compared to manual selection
                </p>
              </div>
              <div className="space-y-2">
                <Target className="h-12 w-12 mx-auto text-accent" />
                <h3 className="text-xl font-bold">94% Accuracy</h3>
                <p className="text-primary-foreground/80 text-sm">
                  AI-driven matching success rate
                </p>
              </div>
              <div className="space-y-2">
                <CheckCircle className="h-12 w-12 mx-auto text-accent" />
                <h3 className="text-xl font-bold">100% Compliant</h3>
                <p className="text-primary-foreground/80 text-sm">
                  Affirmative action and diversity requirements
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}