import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  Building2, 
  Mail, 
  Lock, 
  Phone,
  MapPin,
  Briefcase,
  BookOpen,
  Eye,
  EyeOff
} from "lucide-react";
import { toast } from "sonner";

export default function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [activeTab, setActiveTab] = useState("student");

  const handleLogin = (type: string) => {
    toast.success(`${type} login successful!`, {
      description: "Welcome to the PM Internship Platform"
    });
  };

  return (
    <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-6">
      <div className="w-full max-w-4xl grid lg:grid-cols-2 gap-8 items-center">
        
        {/* Left Side - Welcome Content */}
        <div className="text-primary-foreground space-y-6">
          <div>
            <h1 className="text-5xl font-bold mb-4">
              Welcome to 
              <span className="text-accent block">PM Internship Portal</span>
            </h1>
            <p className="text-xl text-primary-foreground/80 leading-relaxed">
              Connect with opportunities that match your skills and aspirations. 
              Join thousands of students and companies in India's smartest internship ecosystem.
            </p>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-accent rounded-full"></div>
              <span>AI-powered skill matching</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-accent rounded-full"></div>
              <span>Real-time opportunity alerts</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-accent rounded-full"></div>
              <span>Secure and verified placements</span>
            </div>
          </div>
        </div>

        {/* Right Side - Login Forms */}
        <Card className="bg-gradient-card shadow-custom-glow">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-2xl text-primary">Sign In</CardTitle>
            <CardDescription>
              Choose your account type to access the platform
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="student" className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Student
                </TabsTrigger>
                <TabsTrigger value="company" className="flex items-center gap-2">
                  <Building2 className="h-4 w-4" />
                  Company
                </TabsTrigger>
              </TabsList>

              {/* Student Login */}
              <TabsContent value="student" className="space-y-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="student-email" className="flex items-center gap-2">
                      <Mail className="h-4 w-4" />
                      Email Address
                    </Label>
                    <Input 
                      id="student-email" 
                      type="email" 
                      placeholder="student@example.com"
                      className="h-12"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="student-password" className="flex items-center gap-2">
                      <Lock className="h-4 w-4" />
                      Password
                    </Label>
                    <div className="relative">
                      <Input 
                        id="student-password" 
                        type={showPassword ? "text" : "password"}
                        placeholder="Enter your password"
                        className="h-12 pr-10"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-12 px-3 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="student-phone" className="flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      Mobile Number
                    </Label>
                    <Input 
                      id="student-phone" 
                      type="tel" 
                      placeholder="+91 98765 43210"
                      className="h-12"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="student-location" className="flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      Preferred Location
                    </Label>
                    <Input 
                      id="student-location" 
                      type="text" 
                      placeholder="Delhi, Mumbai, Bangalore..."
                      className="h-12"
                    />
                  </div>

                  <Button 
                    className="w-full h-12 bg-primary hover:bg-primary/90"
                    onClick={() => handleLogin("Student")}
                  >
                    <BookOpen className="mr-2 h-5 w-5" />
                    Sign in as Student
                  </Button>
                </div>
              </TabsContent>

              {/* Company Login */}
              <TabsContent value="company" className="space-y-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="company-email" className="flex items-center gap-2">
                      <Mail className="h-4 w-4" />
                      Company Email
                    </Label>
                    <Input 
                      id="company-email" 
                      type="email" 
                      placeholder="hr@company.com"
                      className="h-12"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="company-password" className="flex items-center gap-2">
                      <Lock className="h-4 w-4" />
                      Password
                    </Label>
                    <div className="relative">
                      <Input 
                        id="company-password" 
                        type={showPassword ? "text" : "password"}
                        placeholder="Enter company password"
                        className="h-12 pr-10"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-12 px-3 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="company-name" className="flex items-center gap-2">
                      <Building2 className="h-4 w-4" />
                      Company Name
                    </Label>
                    <Input 
                      id="company-name" 
                      type="text" 
                      placeholder="Acme Corporation Pvt Ltd"
                      className="h-12"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="company-sector" className="flex items-center gap-2">
                      <Briefcase className="h-4 w-4" />
                      Industry Sector
                    </Label>
                    <Input 
                      id="company-sector" 
                      type="text" 
                      placeholder="Technology, Finance, Healthcare..."
                      className="h-12"
                    />
                  </div>

                  <Button 
                    className="w-full h-12 bg-accent hover:bg-accent/90"
                    onClick={() => handleLogin("Company")}
                  >
                    <Building2 className="mr-2 h-5 w-5" />
                    Sign in as Company
                  </Button>
                </div>
              </TabsContent>
            </Tabs>

            <div className="mt-6 text-center text-sm text-muted-foreground">
              <p>Don't have an account? 
                <Button variant="link" className="px-1 text-primary">
                  Register here
                </Button>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}