import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, 
  Building2, 
  MapPin, 
  Calendar, 
  Users, 
  Briefcase,
  DollarSign,
  Clock,
  Star,
  Filter,
  Search
} from "lucide-react";
import { toast } from "sonner";

const mockInternships = [
  {
    id: 1,
    company: "TechCorp India",
    title: "Full Stack Developer Intern",
    location: "Bangalore",
    duration: "6 months",
    stipend: "₹25,000/month",
    skills: ["React", "Node.js", "MongoDB", "TypeScript"],
    applicants: 45,
    posted: "2 days ago",
    rating: 4.8
  },
  {
    id: 2,
    company: "DataSoft Solutions", 
    title: "Machine Learning Intern",
    location: "Hyderabad",
    duration: "4 months",
    stipend: "₹30,000/month",
    skills: ["Python", "TensorFlow", "Pandas", "SQL"],
    applicants: 32,
    posted: "1 week ago",
    rating: 4.6
  },
  {
    id: 3,
    company: "FinTech Innovations",
    title: "Frontend Developer Intern",
    location: "Mumbai",
    duration: "3 months",
    stipend: "₹22,000/month",
    skills: ["React", "JavaScript", "CSS", "Figma"],
    applicants: 28,
    posted: "3 days ago",
    rating: 4.7
  },
  {
    id: 4,
    company: "CloudWorks Ltd",
    title: "DevOps Intern",
    location: "Delhi",
    duration: "5 months",
    stipend: "₹28,000/month",
    skills: ["Docker", "AWS", "Kubernetes", "CI/CD"],
    applicants: 18,
    posted: "5 days ago",
    rating: 4.5
  }
];

export default function Companies() {
  const [showPostForm, setShowPostForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterLocation, setFilterLocation] = useState("");

  const handlePostInternship = () => {
    toast.success("Internship posted successfully!", {
      description: "Your internship opportunity is now live and visible to matched students."
    });
    setShowPostForm(false);
  };

  const filteredInternships = mockInternships.filter(internship =>
    internship.title.toLowerCase().includes(searchTerm.toLowerCase()) &&
    internship.location.toLowerCase().includes(filterLocation.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h1 className="text-4xl font-bold text-primary">Company Portal</h1>
            <p className="text-muted-foreground mt-2">
              Post internships and discover talented students for your organization
            </p>
          </div>
          
          <Button 
            onClick={() => setShowPostForm(!showPostForm)}
            className="bg-primary hover:bg-primary/90 lg:w-auto"
          >
            <Plus className="mr-2 h-5 w-5" />
            Post New Internship
          </Button>
        </div>

        {/* Post Internship Form */}
        {showPostForm && (
          <Card className="bg-gradient-card shadow-custom-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="h-6 w-6 text-primary" />
                Post Internship Opportunity
              </CardTitle>
              <CardDescription>
                Fill out the details to attract the best candidates for your internship program
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="company-name">Company Name</Label>
                    <Input 
                      id="company-name" 
                      placeholder="Your Company Name"
                      className="h-12"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="job-title">Internship Title</Label>
                    <Input 
                      id="job-title" 
                      placeholder="e.g., Full Stack Developer Intern"
                      className="h-12"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="location">Location</Label>
                    <Input 
                      id="location" 
                      placeholder="City, State"
                      className="h-12"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="duration">Duration</Label>
                    <Input 
                      id="duration" 
                      placeholder="e.g., 6 months"
                      className="h-12"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="stipend">Monthly Stipend</Label>
                    <Input 
                      id="stipend" 
                      placeholder="₹25,000"
                      className="h-12"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="skills">Required Skills</Label>
                  <Input 
                    id="skills" 
                    placeholder="React, Node.js, MongoDB, TypeScript (comma separated)"
                    className="h-12"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Job Description</Label>
                  <Textarea 
                    id="description" 
                    placeholder="Describe the internship role, responsibilities, and learning opportunities..."
                    rows={5}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="positions">Number of Positions</Label>
                    <Input 
                      id="positions" 
                      type="number" 
                      placeholder="5"
                      className="h-12"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="deadline">Application Deadline</Label>
                    <Input 
                      id="deadline" 
                      type="date"
                      className="h-12"
                    />
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button 
                    type="button"
                    onClick={handlePostInternship}
                    className="bg-success hover:bg-success/90"
                  >
                    <Briefcase className="mr-2 h-5 w-5" />
                    Post Internship
                  </Button>
                  <Button 
                    type="button"
                    variant="outline"
                    onClick={() => setShowPostForm(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Search and Filter */}
        <Card className="bg-gradient-card shadow-custom-md">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Search internships..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-12"
                />
              </div>
              <div className="relative lg:w-64">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Filter by location..."
                  value={filterLocation}
                  onChange={(e) => setFilterLocation(e.target.value)}
                  className="pl-10 h-12"
                />
              </div>
              <Button variant="outline" className="lg:w-auto">
                <Filter className="mr-2 h-5 w-5" />
                More Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Available Internships */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-primary">Available Internships</h2>
            <Badge variant="secondary" className="text-lg px-3 py-1">
              {filteredInternships.length} Opportunities
            </Badge>
          </div>

          <div className="grid gap-6">
            {filteredInternships.map((internship) => (
              <Card key={internship.id} className="hover:shadow-custom-lg transition-all duration-300 bg-gradient-card">
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    
                    {/* Main Info */}
                    <div className="flex-1 space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="text-xl font-bold text-primary mb-1">
                            {internship.title}
                          </h3>
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Building2 className="h-4 w-4" />
                            <span className="font-medium">{internship.company}</span>
                            <div className="flex items-center gap-1">
                              <Star className="h-4 w-4 fill-current text-accent" />
                              <span className="text-sm">{internship.rating}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {internship.location}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {internship.duration}
                        </div>
                        <div className="flex items-center gap-1">
                          <DollarSign className="h-4 w-4" />
                          {internship.stipend}
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          {internship.applicants} applicants
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {internship.skills.map((skill, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col lg:items-end gap-3 lg:text-right">
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        Posted {internship.posted}
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                        <Button size="sm" className="bg-primary hover:bg-primary/90">
                          View Applicants
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Analytics Summary */}
        <Card className="bg-gradient-primary text-primary-foreground shadow-custom-glow">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Platform Analytics</CardTitle>
            <CardDescription className="text-primary-foreground/80">
              Real-time insights into internship matching performance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6 text-center">
              <div className="space-y-2">
                <h3 className="text-3xl font-bold text-accent">1,245</h3>
                <p className="text-primary-foreground/80 text-sm">Active Students</p>
              </div>
              <div className="space-y-2">
                <h3 className="text-3xl font-bold text-accent">156</h3>
                <p className="text-primary-foreground/80 text-sm">Live Internships</p>
              </div>
              <div className="space-y-2">
                <h3 className="text-3xl font-bold text-accent">94%</h3>
                <p className="text-primary-foreground/80 text-sm">Match Success Rate</p>
              </div>
              <div className="space-y-2">
                <h3 className="text-3xl font-bold text-accent">2.3 hrs</h3>
                <p className="text-primary-foreground/80 text-sm">Avg. Match Time</p>
              </div>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}