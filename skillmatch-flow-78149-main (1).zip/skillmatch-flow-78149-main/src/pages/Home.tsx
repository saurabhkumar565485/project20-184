import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Brain, 
  Users, 
  Target, 
  TrendingUp, 
  MapPin, 
  Award,
  ArrowRight,
  CheckCircle,
  Sparkles
} from "lucide-react";
import { Link } from "react-router-dom";

const highlights = [
  {
    icon: Brain,
    title: "AI-Powered Matching",
    description: "Advanced algorithms match students with ideal internships based on skills, preferences, and career goals."
  },
  {
    icon: Users,
    title: "Industry Partnerships",
    description: "Connect with leading companies across sectors offering quality internship opportunities."
  },
  {
    icon: Target,
    title: "Smart Placement",
    description: "Intelligent system considers location, skills, and diversity for optimal matches."
  },
  {
    icon: TrendingUp,
    title: "Career Growth",
    description: "Track progress and build professional networks through structured internship programs."
  }
];

const stats = [
  { label: "Active Students", value: "15,000+", icon: Users },
  { label: "Partner Companies", value: "500+", icon: MapPin },
  { label: "Successful Placements", value: "12,000+", icon: Award },
  { label: "Match Accuracy", value: "94%", icon: Target }
];

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative bg-gradient-hero text-primary-foreground py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-accent/20 px-4 py-2 rounded-full mb-6">
                <Sparkles className="h-4 w-4 text-accent" />
                <span className="text-sm font-medium">AI-Powered Career Matching</span>
              </div>
              
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight mb-6">
                Smart Internship
                <span className="text-accent block">Matching System</span>
              </h1>
              
              <p className="text-xl text-primary-foreground/80 mb-8 leading-relaxed">
                Revolutionizing internship placement through intelligent AI algorithms. 
                Connect students with perfect opportunities while ensuring diversity and optimal industry exposure.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
                  <Link to="/login" className="flex items-center gap-2">
                    Get Started
                    <ArrowRight className="h-5 w-5" />
                  </Link>
                </Button>
                <Button 
                  asChild 
                  variant="outline" 
                  size="lg"
                  className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10"
                >
                  <Link to="/project-info">
                    Learn More
                  </Link>
                </Button>
              </div>
            </div>

            <div className="relative">
              <Card className="bg-gradient-card shadow-custom-glow">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-6 w-6 text-primary" />
                    Live Matching Engine
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-success" />
                      <span>Processing 1,245 applications...</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-success" />
                      <span>85 new matches found</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-success" />
                      <span>Diversity quotas: 92% achieved</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-6 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index} className="text-center bg-gradient-card shadow-custom-md">
                  <CardContent className="p-6">
                    <Icon className="h-8 w-8 text-primary mx-auto mb-3" />
                    <div className="text-3xl font-bold text-primary mb-1">{stat.value}</div>
                    <div className="text-muted-foreground">{stat.label}</div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Project Background */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-primary mb-4">
              Solving India's Internship Challenge
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              The PM Internship Scheme enables students to gain industry exposure, 
              but matching thousands of applicants with suitable opportunities remains complex.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-bold text-primary mb-6">The Problem</h3>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  Traditional internship matching processes lead to suboptimal selections, 
                  delays, and missed opportunities for both students and companies.
                </p>
                <p>
                  Manual processing of thousands of applications makes it difficult to ensure:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Skills-based matching</li>
                  <li>Geographic preferences</li>
                  <li>Diversity and inclusion</li>
                  <li>Industry capacity optimization</li>
                </ul>
              </div>
            </div>

            <Card className="bg-gradient-card shadow-custom-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-6 w-6 text-primary" />
                  Our Solution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <p className="text-muted-foreground mb-4">
                    AI-driven automated system that intelligently matches candidates with opportunities:
                  </p>
                  <div className="space-y-3">
                    {[
                      "Skills & qualifications analysis",
                      "Location preference matching",
                      "Sector interest alignment",
                      "Affirmative action compliance",
                      "Real-time capacity tracking"
                    ].map((feature, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-success flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Highlights Section */}
      <section className="py-20 px-6 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-primary mb-4">
              Platform Highlights
            </h2>
            <p className="text-xl text-muted-foreground">
              Experience the future of internship placement with our intelligent system
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {highlights.map((highlight, index) => {
              const Icon = highlight.icon;
              return (
                <Card key={index} className="group hover:shadow-custom-glow transition-all duration-300 bg-gradient-card">
                  <CardHeader className="text-center">
                    <div className="mx-auto w-16 h-16 bg-gradient-primary rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                      <Icon className="h-8 w-8 text-primary-foreground" />
                    </div>
                    <CardTitle className="text-primary">{highlight.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground text-center">
                      {highlight.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}